1.将lib下所有的库拷贝到cppPlayDemo_x86下，包括HCNetSDKCom文件夹
2.Device.ini中填入相关的设备信息
3.在终端输入make命令即可生成PlayCtrlDemo，使用./PlayCtrlDemo即可执行
  